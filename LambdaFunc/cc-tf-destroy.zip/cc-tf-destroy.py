import os
import boto3

s3 = boto3.client('s3')

# os.system(f"pip3 install python-terraform")

from python_terraform import *

def lambda_handler(event, context):
    #!/bin/python
    # s3 = boto3.client('s3')
    # Set the S3 bucket and state file name
    bucket_name = 'cc-aline-ecs-bucket'
    state_file_key = 'terraform_state_two.tfstate'
    s3.download_file(bucket_name, state_file_key, '/tmp/terraform.tfstate')
    # # Download the state file from S3 to /tmp
    # s3.download_file(bucket_name, state_file_key, '/tmp/terraform.tfstate')
    # tf = Terraform(working_dir='../cc-terraform-ecs')
    tf = Terraform(working_dir='/tmp/terraform.tfstate')
    # approve = {"auto-approve": True}
    print(tf.init())
    print(tf.plan(no_color=IsFlagged, refresh=False, capture_output=True))
    # print(tf.apply(skip_plan=True, capture_output=True))
    print(tf.apply(destroy=True, auto_approve=True, capture_output=True))













# import os
# import boto3
# from terraform import Terraform

# s3 = boto3.client('s3')

# # def lambda_handler(event, context):

#     # Set the S3 bucket and state file name
#     bucket_name = 'cc-aline-ecs-bucket'
#     state_file_key = 'terraform_state_two.tfstate'

#     # Download the state file from S3 to /tmp
#     s3.download_file(bucket_name, state_file_key, '/tmp/terraform.tfstate')

#     os.system(f"pip install python-terraform")

#     tf = Terraform(working_dir='/path/to/terraform/directory')
#     tf.init()
#     tf.destroy()
#     return {'message': 'Terraform destroy completed successfully'}






































# import boto3
# import os
# import subprocess

# def download_terraform(version):
#     print('Downloading Terraform...')
#     url = f'https://releases.hashicorp.com/terraform/{version}/terraform_{version}_linux_amd64.zip'
#     subprocess.run(['curl', '-LOk', url])
#     subprocess.run(['unzip', f'terraform_{version}_linux_amd64.zip'])
#     os.remove(f'terraform_{version}_linux_amd64.zip')

# def lambda_handler(event, context):
#     # Set AWS credentials
#     os.environ['AWS_ACCESS_KEY_ID'] = 'AKIATPLVG7PRDYY4TIEO'
#     os.environ['AWS_SECRET_ACCESS_KEY'] = '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'
    
#     # Set the Terraform version
#     version = '1.3.7'
    
#     # Set the S3 bucket and state file key
#     bucket_name = 'cc-aline-ecs-bucket'
#     state_key = 'terraform_state_two.tfstate'
#     state_file = 'terraform.tfstate'
    
#     # Download Terraform
#     download_terraform(version)
    
#     # Download the state file from S3
#     s3 = boto3.client('s3')
#     s3.download_file(bucket_name, state_key, state_file)
    
#     # Run Terraform destroy
#     subprocess.run(['./terraform', 'destroy', '-auto-approve'])
    
#     # Upload the updated state file to S3
#     s3.upload_file(state_file, bucket_name, state_key)


































# import os
# import boto3

# def download_terraform(version):
#     os.system(f"curl -O https://releases.hashicorp.com/terraform/{version}/terraform_{version}_linux_amd64.zip")
#     os.system(f"unzip terraform_{version}_linux_amd64.zip")
#     os.system(f"rm terraform_{version}_linux_amd64.zip")

# def lambda_handler(event, context):
#     version = '1.3.7'
#     arch = 'amd64' if os.uname().machine == 'x86_64' else '386'

#     os.system(f"curl -O https://releases.hashicorp.com/terraform/{version}/terraform_{version}_linux_{arch}.zip")
#     os.system(f"unzip terraform_{version}_linux_{arch}.zip")
#     os.system(f"rm terraform_{version}_linux_{arch}.zip")
    
#     s3 = boto3.client('s3')
#     bucket_name = 'cc-aline-ecs-bucket'
#     state_key = 'terraform_state_two.tfstate'
#     state_file = '/tmp/terraform.tfstate'
#     s3.download_file(bucket_name, state_key, state_file)

#     os.chdir('/tmp')
#     os.system(f"./terraform destroy -auto-approve")
    
#     s3.upload_file(state_file, bucket_name, state_key)






































# import os
# import platform
# import boto3

# s3 = boto3.client('s3')

# def download_terraform(version):
#     system = platform.system().lower()
#     if system == 'linux':
#         arch = 'amd64' if platform.machine().endswith('64') else '386'
#         download_url = f'https://releases.hashicorp.com/terraform/{version}/terraform_{version}_linux_{arch}.zip'
#     elif system == 'windows':
#         download_url = f'https://releases.hashicorp.com/terraform/{version}/terraform_{version}_windows_amd64.zip'
#     else:
#         raise Exception(f'Unsupported system: {system}')
        
#     os.system(f'curl {download_url} -o terraform.zip')
#     os.system('unzip terraform.zip')
#     os.system('rm terraform.zip')

# def lambda_handler(event, context):
#     version = '1.3.7'
#     bucket_name = 'cc-aline-ecs-bucket'
#     state_key = 'terraform_state_two.tfstate'
#     state_file = '/tmp/terraform.tfstate'

#     download_terraform(version)
    
#     s3.download_file(bucket_name, state_key, state_file)
    
#     os.system(f'./terraform destroy -auto-approve -state={state_file} -var-file=/dev/null')
    
#     os.remove('terraform')
#     os.remove(state_file)
















































# import os
# import boto3
# import subprocess
# import requests
# import platform

# def download_terraform(version):
#     # Determine the Terraform binary filename based on the OS and architecture
#     os_name = 'linux' if os.name == 'posix' else 'windows'
#     arch = 'amd64' if platform.machine().endswith('64') else '386'
#     filename = f'terraform_{version}_{os_name}_{arch}.zip'

#     # Download the Terraform binary from the official website
#     url = f'https://releases.hashicorp.com/terraform/{version}/{filename}'
#     response = requests.get(url)
#     response.raise_for_status()

#     # Write the binary to disk
#     with open('/tmp/terraform.zip', 'wb') as f:
#         f.write(response.content)

#     # Extract the binary and make it executable
#     subprocess.check_call(['unzip', '/tmp/terraform.zip'])
#     subprocess.check_call(['chmod', '+x', 'terraform'])
#     subprocess.check_call(['mv', 'terraform', '/usr/local/bin'])

# def lambda_handler(event, context):
#     # Download and install Terraform
#     version = '1.3.7'
#     download_terraform(version)

#     # S3 bucket and key where the Terraform state file is located
#     bucket_name = 'cc-aline-ecs-bucket'
#     state_key = 'terraform_state_two.tfstate'

#     # Download the Terraform state file from S3
#     s3 = boto3.client('s3')
#     state_file = '/tmp/terraform.tfstate'
#     s3.download_file(bucket_name, state_key, state_file)

#     try:
#         # Change the directory to where your Terraform files are located
#         os.chdir('/var/task/')

#         # Run the Terraform destroy command with auto-approve flag and S3 backend configuration
#         subprocess.check_call(['terraform', 'init', '-backend-config', f's3_bucket={bucket_name}', '-backend-config', f's3_key={state_key}'])
#         subprocess.check_call(['terraform', 'destroy', '-auto-approve', '-state', state_file])

#         # Upload the updated Terraform state file to S3
#         s3.upload_file(state_file, bucket_name, state_key)

#         return {'status': 'success'}
#     except subprocess.CalledProcessError as e:
#         return {'status': 'error', 'message': e.output}












































# # -*- coding: utf-8 -*-

# import os
# import subprocess
# import urllib

# import boto3


# # Version of Terraform that we're using
# TERRAFORM_VERSION = '1.3.7'

# # Download URL for Terraform
# TERRAFORM_DOWNLOAD_URL = (
#     'https://releases.hashicorp.com/terraform/%s/terraform_%s_linux_amd64.zip'
#     % (TERRAFORM_VERSION, TERRAFORM_VERSION))

# # Paths where Terraform should be installed
# TERRAFORM_DIR = os.path.join('/tmp', 'terraform_%s' % TERRAFORM_VERSION)
# TERRAFORM_PATH = os.path.join(TERRAFORM_DIR, 'terraform')


# def check_call(args):
#     """Wrapper for subprocess that checks if a process runs correctly,
#     and if not, prints stdout and stderr.
#     """
#     proc = subprocess.Popen(args,
#         stdout=subprocess.PIPE,
#         stderr=subprocess.PIPE,
#         cwd='/tmp')
#     stdout, stderr = proc.communicate()
#     if proc.returncode != 0:
#         print(stdout)
#         print(stderr)
#         raise subprocess.CalledProcessError(
#             returncode=proc.returncode,
#             cmd=args)


# def install_terraform():
#     """Install Terraform on the Lambda instance."""
#     # Most of a Lambda's disk is read-only, but some transient storage is
#     # provided in /tmp, so we install Terraform here.  This storage may
#     # persist between invocations, so we skip downloading a new version if
#     # it already exists.
#     # http://docs.aws.amazon.com/lambda/latest/dg/lambda-introduction.html
#     if os.path.exists(TERRAFORM_PATH):
#         return

#     urllib.urlretrieve(TERRAFORM_DOWNLOAD_URL, '/tmp/terraform.zip')

#     # Flags:
#     #   '-o' = overwrite existing files without prompting
#     #   '-d' = output directory
#     check_call(['unzip', '-o', '/tmp/terraform.zip', '-d', TERRAFORM_DIR])

#     check_call([TERRAFORM_PATH, '--version'])


# def destroy_terraform_plan(s3_bucket, path):
#     """Download a Terraform plan from S3 and run a 'terraform destroy'.
#     :param s3_bucket: Name of the S3 bucket where the plan is stored.
#     :param path: Path to the Terraform planfile in the S3 bucket.
#     """
#     # Although the /tmp directory may persist between invocations, we always
#     # download a new copy of the planfile, as it may have changed externally.
#     s3 = boto3.resource('s3')
#     planfile = s3.Object(s3_bucket, path)
#     planfile.download_file('/tmp/terraform.plan')
#     check_call([TERRAFORM_PATH, 'destroy', '/tmp/terraform.plan'])


# def lambda_handler(event, context):
#     s3_bucket = event['Records'][0]['s3']['bucket']['cc-aline-ecs-bucket']
#     path = event['Records'][0]['s3']['object']['terraform_state_two.tfstate']

#     install_terraform()
#     destroy_terraform_plan(s3_bucket=s3_bucket, path=path)